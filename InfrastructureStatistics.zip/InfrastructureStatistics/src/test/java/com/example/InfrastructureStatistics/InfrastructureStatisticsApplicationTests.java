package com.example.InfrastructureStatistics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfrastructureStatisticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
